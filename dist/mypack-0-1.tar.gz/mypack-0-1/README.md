# MyPackage
This library was created as an example of how to publish your own python package.

# How to install
...